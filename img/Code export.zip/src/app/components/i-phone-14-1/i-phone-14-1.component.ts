import { Component } from '@angular/core';
import type { OnInit } from '@angular/core';

/* @figmaId 1:4 */
@Component({
  selector: 'cl-i-phone-14-1',
  templateUrl: './i-phone-14-1.component.html',
  styleUrls: ['./i-phone-14-1.component.css'],
})
export class IPhone141Component implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
